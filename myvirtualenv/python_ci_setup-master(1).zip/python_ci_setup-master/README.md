### Pyton project 4 promocion

## Codebeat
[![codebeat badge](https://codebeat.co/badges/6bb2daeb-6b16-4d91-a123-8d05dd68a9e6)](https://codebeat.co/projects/github-com-scrodrig-python_ci_setup-master)

## travisCi
[![Build Status](https://travis-ci.org/scrodrig/python_ci_setup.svg?branch=master)](https://travis-ci.org/scrodrig/python_ci_setup)
## Codacy code
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/d66776706db94ed5b641e13d5738dca0)](https://www.codacy.com/app/schubert_david/python_ci_setup?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=scrodrig/python_ci_setup&amp;utm_campaign=Badge_Grade)
## Codacy coverage
[![Codacy Badge](https://api.codacy.com/project/badge/Coverage/d66776706db94ed5b641e13d5738dca0)](https://www.codacy.com/app/schubert_david/python_ci_setup?utm_source=github.com&utm_medium=referral&utm_content=scrodrig/python_ci_setup&utm_campaign=Badge_Coverage)
## Snyk
[![Known Vulnerabilities](https://snyk.io/test/github/scrodrig/python_ci_setup/badge.svg?targetFile=requirements.txt)](https://snyk.io/test/github/scrodrig/python_ci_setup?targetFile=requirements.txt)
