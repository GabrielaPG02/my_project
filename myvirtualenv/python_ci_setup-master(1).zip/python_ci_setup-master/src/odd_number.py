class OddNumber:

    @staticmethod
    def odd_number(number):
        if number % 2 == 0:
            return True
        return False
